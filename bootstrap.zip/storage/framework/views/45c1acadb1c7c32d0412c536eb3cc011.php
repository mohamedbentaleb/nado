<?php $__env->startSection('title' , 'Users | nado.ma'); ?>


<?php $__env->startSection('content'); ?>
<div id="main-content">
    <div class="page-heading">
        <h3>Users</h3>
    </div>
    <div class="page-content">
    <section class="section">
      <div class="card">
        <div class="card-header d-flex justify-content-between">
            <h4 class="card-title">List Users</h4>
            <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary float-right">New User</a>
        </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-striped mb-0 display" id="example">
                  <thead>
                      <tr>
                          <th>#</th>
                          <th>Name</th>
                          <th>Email</th>
                          <th class="d-flex justify-content-end">Action</th>
                      </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <th scope="row"><?php echo e($user->id); ?></th>
                      <td><?php echo e($user->name); ?></td>
                      <td><?php echo e($user->email); ?></td>
                      <td>
                        <div class="d-flex gap-2 w-100 justify-content-end">
                          <a href="<?php echo e(route("users.edit" , $user)); ?>" class="btn btn-info">Update</a>
                          <?php echo $__env->make('admin.partials.deleteBtn', [  "url" =>  route('users.destroy' , $user) ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                  <tfoot>
                      <tr>
                        <th>Id</th>
                        <th>Name</th>
                        <th>Email</th>
                      </tr>
                  </tfoot>
              </table>
          </div>
      </div>
  </section>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bentaleb\Desktop\nado\resources\views/admin/users/index.blade.php ENDPATH**/ ?>