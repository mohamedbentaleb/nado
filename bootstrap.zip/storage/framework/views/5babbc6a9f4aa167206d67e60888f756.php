<?php $__env->startSection('title' , 'Avis videos | nado.ma'); ?>


<?php $__env->startSection('content'); ?>
<div id="main-content">
<div class="page-heading">
    <h3>Avis videos</h3>
</div>
<div class="page-content">
    <section class="row">
      <div class="row" id="table-striped">
          <div class="col-12">
              <div class="card">
                  <div class="card-header d-flex justify-content-between">
                      <h4 class="card-title">List Avis videos</h4>
                      <a href="<?php echo e(route('avisvideos.create')); ?>" class="btn btn-primary float-right">New Avis videos</a>
                  </div>
                  <div class="card-content">
                      <div class="card-body">
                      <div class="table-responsive mx-4 my-2">
                          <table class="table table-striped mb-0 display" id="example">
                              <thead>
                                  <tr>
                                      <th>title</th>
                                      <th>video key youtube</th>
                                      <th class="d-flex justify-content-end">Action</th>
                                  </tr>
                              </thead>
                              <tbody>
                                <?php $__currentLoopData = $avisvideos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $av): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <tr>
                                      <td><?php echo e($av->title); ?></td>
                                      <td><?php echo e($av->video_key); ?></td>
                                      <td>
                                        <div class="d-flex gap-2 w-100 justify-content-end">
                                          <a href="<?php echo e(route("avisvideos.edit" , $av)); ?>" class="btn btn-info">Update</a>
                                          <?php echo $__env->make('admin.partials.deleteBtn', ["url" =>  route('avisvideos.destroy' , $av) ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                      </td>
                                  </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </tbody>

                            <tfoot>
                                <tr>
                                    <th>title</th>
                                    <th>video key youtube</th>
                                </tr>
                            </tfoot>
                          </table>
                      </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
</section>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bentaleb\Desktop\nado\resources\views/admin/avisvideos/index.blade.php ENDPATH**/ ?>