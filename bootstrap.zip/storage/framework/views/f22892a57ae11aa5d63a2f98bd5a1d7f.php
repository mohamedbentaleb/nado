<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
        <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <body id="bg" class="font-poppins home-2">

        <div class="page-wraper">
            <div id="loading-area"></div>
            <?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Content -->
            <div class="page-content">
                <?php echo $__env->yieldContent('content'); ?>
            <!-- Content END-->
                <?php echo $__env->make('layouts.bottom-page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </body>
</html>

<?php /**PATH C:\Users\Bentaleb\Desktop\nado\resources\views/layouts/app.blade.php ENDPATH**/ ?>