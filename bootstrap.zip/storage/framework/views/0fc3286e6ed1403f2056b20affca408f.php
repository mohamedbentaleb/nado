<?php
    $btn_text  ??= 'Delete';
    $class ??= null;
    $url ??= '/';
?>

<a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['btn-del-row btn btn-danger', $class ]); ?>"  data-bs-toggle="modal" data-bs-target="#md-del-row" data-url="<?php echo e($url); ?>">
    <?php echo e($btn_text); ?>

</a>
<?php /**PATH C:\Users\Bentaleb\Desktop\nado\resources\views/admin/partials/deleteBtn.blade.php ENDPATH**/ ?>