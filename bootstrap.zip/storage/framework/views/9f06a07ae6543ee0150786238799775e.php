<?php
    $value ??= '';
    $name  ??= '';
    $type  ??= 'text';
    $label ??= ucfirst($name);
    $class ??= null;
    $id ??= $name;
    $hasicon ??= '';
    $classicon = ($hasicon != '') ? 'has-icon-left' : '';
?>

<div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['form-group', $class, $classicon ]); ?>">
    <label for="<?php echo e($name); ?>"><?php echo e($label); ?></label>

    <div class="position-relative">
    <?php if($type == "textarea"): ?>
        <textarea name="<?php echo e($name); ?>" id="<?php echo e($id); ?>" class="form-control <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="3"><?php echo e(old($name , $value)); ?></textarea>
    <?php else: ?>
        <input type="<?php echo e($type); ?>" name="<?php echo e($name); ?>" id="<?php echo e($name); ?>" class="form-control round <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  value="<?php echo e(old($name , $value)); ?>" >
        <?php if($hasicon): ?>
            <div class="form-control-icon">
                <i class="bi bi-<?php echo e($hasicon); ?>"></i>
            </div>
        <?php endif; ?>

   <?php endif; ?>
    <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="invalid-feedback">
            <?php echo e($message); ?>

        </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<?php /**PATH C:\Users\Bentaleb\Desktop\nado\resources\views/admin/partials/input.blade.php ENDPATH**/ ?>