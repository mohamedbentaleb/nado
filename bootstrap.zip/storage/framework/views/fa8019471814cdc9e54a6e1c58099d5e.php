<!DOCTYPE html>
<html>
<head>
    <title>nado.ma</title>
</head>
<body>
    <h1>Subject: <?php echo e($data['subject']); ?></h1>
    <p>Nom: <?php echo e($data['name']); ?></p>
    <p>Phone: <?php echo e($data['phone']); ?></p>
    <p>Email: <?php echo e($data['email']); ?></p>

    <p><?php echo e($data['message']); ?></p>

    <p>Thank you</p>
</body>
</html>
<?php /**PATH C:\Users\Bentaleb\Desktop\nado\resources\views/mail/email.blade.php ENDPATH**/ ?>