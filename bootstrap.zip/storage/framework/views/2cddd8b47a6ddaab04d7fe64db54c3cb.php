<?php $__env->startSection('title' , 'Forgot Password'); ?>

<?php $__env->startSection('content'); ?>

    <div class="auth-logo">
        <a href="index.html"><img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="Logo"></a>
    </div>
    <h1 class="auth-title" style="font-size:3rem !important;">Forgot Password</h1>

    <form method="POST" action="<?php echo e(route('password.email')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group position-relative has-icon-left mb-4">
            <input type="email" id="name" class="form-control form-control-xl <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="email" value="<?php echo e(old('email')); ?>" placeholder="Email" required autofocus autocomplete="username">
            <div class="form-control-icon">
                <i class="bi bi-person"></i>
            </div>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <button class="btn btn-primary btn-block btn-lg shadow-lg mt-5">Send</button>
    </form>
    <div class="text-center mt-5 text-lg fs-4">
        <p class='text-gray-600'>Remember your account? <a href="<?php echo e(route('login')); ?>" class="font-bold">Log in</a>
        </p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bentaleb\Desktop\nado\resources\views/admin/auth/forgot-password.blade.php ENDPATH**/ ?>