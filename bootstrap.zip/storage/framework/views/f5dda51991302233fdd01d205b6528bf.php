<?php $__env->startSection('title' , $brand->exists ? 'Edit Brand' : 'New Brand'); ?>



<?php $__env->startSection('content'); ?>
<div id="main-content">
<div class="page-heading">
    <h3>Brand</h3>
</div>
<div class="page-content">
    <section class="row">
    <div class="row match-height">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">New brand</h4>
                </div>
                <div class="card-content">
                    <div class="card-body row">
                        <div class="col-md-6 col-12 offset-md-3">
                            <form action="<?php echo e(route($brand->exists ? 'brands.update' : 'brands.store' , $brand)); ?>"  method="post" class="form form-vertical" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field($brand->exists ? 'PUT' : 'POST'); ?>
                                <div class="form-body">
                                    <div class="row">
                                        <div class="col-12 my-2">
                                            <?php echo $__env->make('admin.partials.input', ["class" => 'col', "label" => "Name" ,"name" => 'name', "value" => $brand->name], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                        <div class="col-12 my-2">
                                            <div class="form-group">
                                                <label for="logo">Logo</label>
                                                    <input type="file" name="logo" id="logo" class="form-control round <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                                                <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback">
                                                        <?php echo e($message); ?>

                                                    </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                <?php if($brand->exists): ?>
                                                    <img src="<?php echo e(asset('storage/brand/'.$brand->logo)); ?>" width="30%">
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-12 d-flex justify-content-center">
                                            <button type="submit" class="btn btn-primary me-1 mb-1">
                                                <?php if($brand->exists): ?>
                                                    Update
                                                <?php else: ?>
                                                    Save
                                                <?php endif; ?>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bentaleb\Desktop\nado\resources\views/admin/brands/form.blade.php ENDPATH**/ ?>