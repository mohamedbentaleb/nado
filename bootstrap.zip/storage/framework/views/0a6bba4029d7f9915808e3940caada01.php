<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo $__env->yieldContent('title'); ?></title>

        <link rel="stylesheet" href="<?php echo e(asset('assets/back/assets/css/main/app.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/back/assets/css/pages/auth.css')); ?>">
        <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.png')); ?>" type="image/png">

        <link rel="stylesheet" href="<?php echo e(asset('assets/back/assets/css/shared/iconly.css')); ?>">
        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    </head>

    <body>
        <div id="auth">

            <div class="row h-100">
                <div class="col-lg-5 col-12">
                    <div id="auth-left">
                        <?php echo $__env->make('admin.partials.flashdata', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </div>
                <div class="col-lg-7 d-none d-lg-block" >
                    <div id="auth-right" style="background: #f5c04a;">

                    </div>
                </div>
            </div>

        </div>
    </body>

</html>
<?php /**PATH C:\Users\Bentaleb\Desktop\nado\resources\views/admin/layouts/guest.blade.php ENDPATH**/ ?>