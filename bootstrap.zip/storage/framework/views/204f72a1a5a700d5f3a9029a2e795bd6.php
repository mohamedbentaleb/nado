<?php if(isset($breadcrumbItems)): ?>
    <div class="row">
        <div class="col-12 mx-3">
            <nav aria-label="breadcrumb" class="breadcrumb-header">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href=" <?php echo e(route('dashboard')); ?> ">Dashboard</a></li>
                    <?php $__currentLoopData = $breadcrumbItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($link !== ""): ?>
                            <li class="breadcrumb-item"><a href=" <?php echo e($link); ?>" ><?php echo e($k); ?></a></li>
                        <?php else: ?>
                            <li class="breadcrumb-item active"><?php echo e($k); ?></li>
                        <?php endif; ?>                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ol>
            </nav>
        </div>
    </div>    
<?php endif; ?><?php /**PATH C:\Users\Bentaleb\Desktop\nado\resources\views/admin/partials/breadcrumbs.blade.php ENDPATH**/ ?>