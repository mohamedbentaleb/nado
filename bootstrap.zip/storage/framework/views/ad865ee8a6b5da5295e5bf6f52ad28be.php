<?php
    $data  ??=  [];
    $value ??= '';
    $name  ??= '';
    $label ??= ucfirst($name);
    $class ??= null;
    $multiple ??= '';

    //dd($data);
?>
<!--multiple   []-->
<div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['form-group', $class ]); ?>">
    <label for="<?php echo e($name); ?>"><?php echo e($label); ?></label>

    <select name="<?php echo e($name); ?><?php if($multiple): ?>[]<?php endif; ?>" id="<?php echo e($name); ?>" class="form-select <?php if($multiple): ?> choices <?php endif; ?> <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" <?php echo e($multiple); ?>>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($k); ?>" <?php if($multiple): ?> <?php if($value->contains($k)): echo 'selected'; endif; ?> <?php else: ?> <?php if($value == $k): echo 'selected'; endif; ?> <?php endif; ?>><?php echo e($v); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>


    <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="invalid-feedback">
            <?php echo e($message); ?>

        </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php /**PATH C:\Users\Bentaleb\Desktop\nado\resources\views/admin/partials/select.blade.php ENDPATH**/ ?>